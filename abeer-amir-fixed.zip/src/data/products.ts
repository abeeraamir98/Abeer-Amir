export const products = [
  {
    id: 1,
    name: "Premium Hoodie",
    price: "PKR 3999",
    image: "/hoodie.jpg"
  },
  {
    id: 2,
    name: "Classic T-Shirt",
    price: "PKR 1499",
    image: "/shirt1.jpg"
  }
]