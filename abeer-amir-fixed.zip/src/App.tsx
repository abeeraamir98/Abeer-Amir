import Header from './components/Header'
import Hero from './components/Hero'
import Products from './components/Products'
import Footer from './components/Footer'
import TrustSignals from './components/TrustSignals'
import ErrorBoundary from './components/ErrorBoundary'

export default function App() {
  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-black text-white">
        <Header />
        <Hero />
        <TrustSignals />
        <Products />
        <Footer />
      </div>
    </ErrorBoundary>
  )
}