export default function TrustSignals() {
  return (
    <div className="text-center text-gray-400 py-10">
      Fast Delivery • Cash on Delivery • Easy Returns
    </div>
  )
}