export default function Header() {
  return (
    <header className="p-6 flex justify-between border-b border-gray-800">
      <h1 className="font-bold">AbeerAmir</h1>
      <a href="https://wa.me/923006190087" className="border px-4 py-2">
        Order
      </a>
    </header>
  )
}