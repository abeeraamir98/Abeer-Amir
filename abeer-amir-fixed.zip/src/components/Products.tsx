import { products } from '../data/products'

export default function Products() {
  return (
    <section className="grid grid-cols-1 md:grid-cols-2 gap-6 p-6">
      {products.map(p => (
        <div key={p.id} className="border p-4">
          <img src={p.image} className="w-full h-60 object-cover" />
          <h3 className="mt-2">{p.name}</h3>
          <p>{p.price}</p>
        </div>
      ))}
    </section>
  )
}