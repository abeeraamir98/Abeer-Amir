export default function Hero() {
  return (
    <section className="text-center py-20">
      <h2 className="text-4xl font-bold">Premium Streetwear</h2>
      <p className="text-gray-400 mt-4">Made for modern style</p>
    </section>
  )
}